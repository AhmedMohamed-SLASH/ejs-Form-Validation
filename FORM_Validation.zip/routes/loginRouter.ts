import express from 'express';
import { dsh } from './dashboard';
// Removed 'log' and 'title' imports as they are not used in this file
// Removed 'path' import as it's not used here

const loginRouter = express.Router();

const credentials = {
    email: "ah@gmail.com",
    password: "ahmed" // Matched to HTML input name
};

loginRouter.post('/', (req, res) => {
    const { email, password } = req.body;

    console.log(`Attempting login for: ${email}`);

    if (email === credentials.email && password === credentials.password) {
        console.log("Login successful!");
        req.session.isLoggedIn = true;
        req.session.userEmail = email;

        res.redirect('/dashboard'); // Redirect to the dashboard route handled by app.ts
    } else {
        console.log("Login failed: Invalid credentials.");
        req.session.errorMessage = "Invalid email or password.";
        res.redirect('/'); // Redirect back to the login page
    }
});

// IMPORTANT FIX: Removed the /dashboard GET route from loginRouter.
// This route should be handled in app.ts, as it relies on global session state
// and avoids route conflicts. The app.ts already handles it correctly.
// loginRouter.get('/dashboard', (req, res) => {
//     if (req.session.isLoggedIn) {
//         res.render(path.join(__dirname, '../views/dashboard.ejs'), {
//             title: "dashboard",
//             user: "ahmed" // This should be req.session.userEmail
//         });
//     } else {
//         res.redirect('/');
//     }
// });

export { loginRouter };
