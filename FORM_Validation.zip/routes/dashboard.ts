import express from 'express'

const dsh = express.Router();

dsh.get('/', (req, res) => {
    // Check if the user is logged in using the session variable
    if (req.session.isLoggedIn) {
        // Render the dashboard page, passing the user's email from the session
        // This 'userEmail' matches what dashboard.ejs expects.
        res.render('dashboard', { title: "User Dashboard", userEmail: req.session.userEmail });
    } else {
        // If not logged in, redirect them back to the login page

        res.redirect('/');
    }
});



export{dsh}