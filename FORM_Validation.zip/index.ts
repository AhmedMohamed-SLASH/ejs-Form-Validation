import express from 'express';
import path from 'path';
import { loginRouter } from './routes/loginRouter'; // Import the login router
import {dsh} from './routes/dashboard'
import session from 'express-session';
import { randomUUID } from 'crypto'; // For generating a random secret for sessions

// Extend the Express session interface for TypeScript type safety.
// This allows you to define custom properties that will exist on req.session.
declare module 'express-session' {
    interface SessionData {
        isLoggedIn: boolean; // To track if a user is logged in
        userEmail: string;   // To store the logged-in user's email
        errorMessage: string; // To pass error messages between requests (e.g., failed login)
    }
}

const app = express();
const PORT = 5500; // Using the PORT you specified

// Set EJS as the template engine and define the views directory
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Configure express-session middleware
app.use(session({
    secret: randomUUID(),
    resave: false,
    saveUninitialized: true,
    cookie: {
        maxAge: 1000 * 60 * 60 * 24 // Cookie valid for 24 hours (in milliseconds)
    }
}));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public/imgs')));

// Middleware to parse incoming request bodies with JSON payloads
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Mount the loginRouter at the '/login' path.
// This means any POST request to /login will be handled by loginRouter.post('/')
app.use('/login', loginRouter);

// Root route: Renders the login form
app.get('/', (req, res) => {
    const errorMessage = req.session.errorMessage || '';
    delete req.session.errorMessage; // Flash message-like behavior: show once then clear
    res.render('base', { title: "Login System", errorMessage: errorMessage });
});

app.use('/dashboard',dsh);

// Logout route: Destroys the user's session
app.get('/logout', (req, res) => {
    console.log("logout");
    req.session.destroy(err => {
        if (err) {
            console.error("Error destroying session:", err);
            return res.redirect('/dashboard');
        }
        res.redirect('/');
    });
});

// Start the server and listen on the specified port
app.listen(PORT, () => {
    console.log(`Server is listening on http://localhost:${PORT}`);
    console.log(`Open your browser at http://localhost:${PORT}`);
});
